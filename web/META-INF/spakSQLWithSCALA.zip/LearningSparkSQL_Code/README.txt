This book is based on Spark 2.2.0 (pre-built for Apache Hadoop 2.7 or later) and Scala
2.11.8. For one or two subsections, Spark 2.1.0 has also been used due to the unavailability
of certain libraries and reported bugs (when used with Apache Spark 2.2). The hardware
and OS specifications include minimum 8 GB RAM (16 GB strongly recommended), 100 GB
HDD, and OS X 10.11.6 or later (or appropriate Linux versions recommended for Spark
development).